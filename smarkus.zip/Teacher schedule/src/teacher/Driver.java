package teacher;

public class Driver {

	public static void main(String[] args) {
		
		//Set schedules for each day
		
		Monday m = new Monday();
		Tuesday t = new Tuesday();
		Wednesday w = new Wednesday();
		Thursday th = new Thursday();
		Friday f = new Friday();
		
		m.matrix();
		System.out.println();
		t.matrix();
		System.out.println();
		w.matrix();
		System.out.println();
		th.matrix();
		System.out.println();
		f.matrix();
	}

}
