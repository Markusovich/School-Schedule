package teacher;

import java.util.ArrayList;
import java.util.Random;

public class Tuesday {
	
	public Tuesday(){}
	
	public void matrix(){
		
		System.out.println("Tuesday:");
		int i, j;
		int [][] s = new int[6][6];
		
		{
		s[0][0]=1; s[0][1]=0; s[0][2]=0; s[0][3]=0; s[0][4]=0; s[0][5]=0;  //SCHEDULE
		s[1][0]=0; s[1][1]=1; s[1][2]=0; s[1][3]=0; s[1][4]=0; s[1][5]=0;
		s[2][0]=0; s[2][1]=0; s[2][2]=1; s[2][3]=0; s[2][4]=0; s[2][5]=0;
		s[3][0]=0; s[3][1]=0; s[3][2]=0; s[3][3]=1; s[3][4]=0; s[3][5]=0;
		s[4][0]=0; s[4][1]=0; s[4][2]=0; s[4][3]=0; s[4][4]=1; s[4][5]=0;
		s[5][0]=0; s[5][1]=0; s[5][2]=0; s[5][3]=0; s[5][4]=0; s[5][5]=1;
		}
		
		Random r = new Random();
		ArrayList<Integer> x = new ArrayList<Integer>();
		x.add(0);
		x.add(1);
		x.add(2);
		x.add(3);
		x.add(4);
		x.add(5);
		
		for(i=0;i<6;i++){
				j = x.get(r.nextInt(x.size()));
				do{j = x.get(r.nextInt(x.size()));} while(s[i][j] == 0);
				while(s[i][j] == 1){
					if(j==0){System.out.println("Class " + (i+1) + " | Teach kindergarden");}
					else{System.out.println("Class " + (i+1) + " | Teach grade " + j);}
					x.remove(new Integer(j));
					break;
				}
		}
	}
}
